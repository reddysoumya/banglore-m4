import { Component, OnInit } from '@angular/core';
import { CollegeService } from './app.collegeservices';

//Meta data
@Component({ 
  selector: 'clg-comp', 
  templateUrl: `./app.college.html`, 
  providers: [CollegeService] 
}) 

 //Creating CollegeComponent class
  export class CollegeComponent implements OnInit {
  myalldata: any[]; //array
  constructor(private collegeservice: CollegeService) {}

  ngOnInit() 
    {
    this.collegeservice.getAll().subscribe((data: any) => this. myalldata = data);
    }
//Delete method implementation
  deleteCollege(index: any) 
 {
    if (index !== -1)
     {
      this. myalldata.splice(index, 1); 
     }
 }

//Method Implementations for Sortings
//method for sorting college Id
  sortById(): void 
  {
    this. myalldata.sort((a,b)=>a.collegeId < b.collegeId ? -1 : a.collegeId > b.collegeId ? 1 : 0);
  }
//method for sorting college Name
  sortByName(): void 
  {
    this. myalldata.sort((a,b)=>a.collegeName < b.collegeName ? -1 : a.collegeName > b.collegeName ? 1 : 0);
  }
//method for sorting State
  sortByState(): void
  {
    this. myalldata.sort((a,b)=>a.state < b.state ? -1 : a.state > b.state ? 1 : 0);
  }

}
