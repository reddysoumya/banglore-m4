import { Injectable } from "@angular/core";
import { Observable } from "rxjs/Observable";
import { Http,Response } from "@angular/http"
import 'rxjs/add/operator/map';

@Injectable() //it is a decorator

export class CollegeService
{
    constructor(private http:Http){}
             //method to get data from json file
    getAll():Observable<any[]>{
    return this.http.get('/app/college.json').map((response:Response)=><any[]>response.json());
}

}